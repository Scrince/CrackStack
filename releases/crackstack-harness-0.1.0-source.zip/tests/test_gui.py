from __future__ import annotations


def test_gui_module_imports():
    import harness.gui as gui

    assert callable(gui.main)

from __future__ import annotations

from dataclasses import dataclass
import importlib.util
import platform
from pathlib import Path
import sys

from harness.config import HarnessConfig
from harness.models import discover_gguf_models, display_model_path
from harness.paths import (
    generated_dir,
    harness_root,
    logs_dir,
    models_dir,
    runtime_dir,
    state_dir,
    workspace_dir,
)


@dataclass(frozen=True)
class Check:
    name: str
    ok: bool
    detail: str


def platform_key() -> str:
    system = platform.system().lower()
    machine = platform.machine().lower()
    if system == "windows" and machine in {"amd64", "x86_64"}:
        return "windows-x64"
    if system == "darwin" and machine == "arm64":
        return "macos-arm64"
    if system == "darwin" and machine in {"x86_64", "amd64"}:
        return "macos-x64"
    if system == "linux" and machine in {"x86_64", "amd64"}:
        return "linux-x64"
    return f"{system}-{machine}"


def _is_importable(module_name: str) -> bool:
    return importlib.util.find_spec(module_name) is not None


def _can_write(directory: Path) -> bool:
    directory.mkdir(parents=True, exist_ok=True)
    probe = directory / ".write-check"
    try:
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
        return True
    except OSError:
        return False


def run_checks(config: HarnessConfig) -> list[Check]:
    key = platform_key()
    root = harness_root()
    bundled_python = runtime_dir() / "python" / key
    if key == "windows-x64":
        python_exe = bundled_python / "python.exe"
    else:
        python_exe = bundled_python / "bin" / "python"

    models = discover_gguf_models()
    checks = [
        Check("harness root", root.exists(), str(root)),
        Check("platform", True, key),
        Check("active python", True, sys.executable),
        Check(
            "bundled python",
            python_exe.exists(),
            str(python_exe) if python_exe.exists() else f"missing: {python_exe}",
        ),
        Check(
            "models",
            bool(models),
            ", ".join(display_model_path(model) for model in models[:5])
            if models
            else f"no .gguf files found under {models_dir()}",
        ),
        Check("configured model", config.model.resolved_path is not None, config.model.path or "not set"),
        Check("llama-cpp-python", _is_importable("llama_cpp"), "import llama_cpp"),
        Check("transformers", _is_importable("transformers"), "import transformers"),
        Check("PyInstaller", _is_importable("PyInstaller"), "python -m PyInstaller"),
    ]

    for name, directory in (
        ("workspace writable", workspace_dir()),
        ("logs writable", logs_dir()),
        ("state writable", state_dir()),
        ("generated writable", generated_dir()),
    ):
        checks.append(Check(name, _can_write(directory), str(directory)))
    return checks


def format_checks(checks: list[Check]) -> str:
    lines = []
    for check in checks:
        status = "ok" if check.ok else "missing"
        lines.append(f"{status:7} {check.name}: {check.detail}")
    return "\n".join(lines)

"""Storage and audit helpers."""

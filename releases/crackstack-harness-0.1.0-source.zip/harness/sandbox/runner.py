from __future__ import annotations

from dataclasses import dataclass
import os
from pathlib import Path
import subprocess
import sys

from harness.paths import harness_root


@dataclass(frozen=True)
class SandboxResult:
    ok: bool
    stdout: str
    stderr: str


def smoke_test_module(module_path: Path, timeout_seconds: int = 10) -> SandboxResult:
    root = harness_root()
    code = """
import importlib.util
import pathlib
import sys

module_path = pathlib.Path(sys.argv[1])
spec = importlib.util.spec_from_file_location("candidate_tool", module_path)
if spec is None or spec.loader is None:
    raise RuntimeError("could not load module spec")
module = importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
if hasattr(module, "smoke_test"):
    module.smoke_test()
if not hasattr(module, "register"):
    raise RuntimeError("tool module must define register(registry)")
print("sandbox smoke test passed")
"""
    env = os.environ.copy()
    env["CRACKSTACK_ROOT"] = str(root)
    env["PYTHONPATH"] = str(root)
    result = subprocess.run(
        [sys.executable, "-c", code, str(module_path)],
        cwd=root,
        env=env,
        text=True,
        capture_output=True,
        timeout=timeout_seconds,
    )
    return SandboxResult(
        ok=result.returncode == 0,
        stdout=result.stdout,
        stderr=result.stderr,
    )

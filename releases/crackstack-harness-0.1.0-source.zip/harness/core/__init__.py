"""Core agent loop primitives."""

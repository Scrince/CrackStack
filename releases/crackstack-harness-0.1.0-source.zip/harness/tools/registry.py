from __future__ import annotations

from dataclasses import dataclass
import inspect
import json
from typing import Any, Callable


ToolFunc = Callable[..., Any]


@dataclass(frozen=True)
class ToolResult:
    ok: bool
    content: str

    @classmethod
    def success(cls, content: object) -> "ToolResult":
        if isinstance(content, str):
            return cls(ok=True, content=content)
        return cls(ok=True, content=json.dumps(content, indent=2, sort_keys=True))

    @classmethod
    def error(cls, content: object) -> "ToolResult":
        return cls(ok=False, content=str(content))


@dataclass(frozen=True)
class Tool:
    name: str
    description: str
    parameters: dict[str, Any]
    func: ToolFunc

    def run(self, arguments: dict[str, Any]) -> ToolResult:
        try:
            accepted = set(inspect.signature(self.func).parameters)
            unexpected = set(arguments) - accepted
            if unexpected:
                return ToolResult.error(f"unexpected parameters: {sorted(unexpected)}")
            return ToolResult.success(self.func(**arguments))
        except Exception as exc:
            return ToolResult.error(f"{type(exc).__name__}: {exc}")


class ToolRegistry:
    def __init__(self) -> None:
        self._tools: dict[str, Tool] = {}

    def register(
        self,
        name: str,
        description: str,
        parameters: dict[str, Any],
        func: ToolFunc,
    ) -> None:
        if name in self._tools:
            raise ValueError(f"tool already registered: {name}")
        self._tools[name] = Tool(
            name=name,
            description=description,
            parameters=parameters,
            func=func,
        )

    def get(self, name: str) -> Tool | None:
        return self._tools.get(name)

    def run(self, name: str, arguments: dict[str, Any]) -> ToolResult:
        tool = self.get(name)
        if tool is None:
            return ToolResult.error(f"unknown tool: {name}")
        return tool.run(arguments)

    def specs(self) -> list[dict[str, Any]]:
        return [
            {
                "name": tool.name,
                "description": tool.description,
                "parameters": tool.parameters,
            }
            for tool in sorted(self._tools.values(), key=lambda item: item.name)
        ]

    def prompt_block(self) -> str:
        if not self._tools:
            return ""
        specs = json.dumps(self.specs(), indent=2, sort_keys=True)
        return (
            "Available tools are listed below as JSON specs. To call a tool, respond only with "
            "a fenced JSON block shaped like:\n"
            "```json\n"
            '{"tool": "tool_name", "arguments": {"key": "value"}}\n'
            "```\n"
            "After observing tool results, provide a normal final answer when done.\n"
            f"{specs}"
        )

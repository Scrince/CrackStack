from __future__ import annotations

import importlib.util
import logging
from pathlib import Path

from harness.tools.registry import ToolRegistry

LOGGER = logging.getLogger(__name__)


def load_tool_module(module_path: Path, registry: ToolRegistry) -> None:
    spec = importlib.util.spec_from_file_location(module_path.stem, module_path)
    if spec is None or spec.loader is None:
        raise RuntimeError(f"could not load module spec: {module_path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    register = getattr(module, "register", None)
    if register is None:
        raise RuntimeError("tool module must define register(registry)")
    register(registry)


def load_generated_tools(directory: Path, registry: ToolRegistry) -> list[str]:
    loaded: list[str] = []
    if not directory.exists():
        return loaded
    for module_path in sorted(directory.glob("*.py")):
        try:
            load_tool_module(module_path, registry)
        except Exception:
            LOGGER.exception("failed to load generated tool module: %s", module_path)
            continue
        loaded.append(module_path.name)
    return loaded

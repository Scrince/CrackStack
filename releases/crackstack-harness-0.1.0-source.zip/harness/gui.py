from __future__ import annotations

import sys
from threading import Event

from PySide6.QtCore import QObject, QRunnable, Qt, QThreadPool, Signal, Slot
from PySide6.QtGui import QFont
from PySide6.QtWidgets import (
    QApplication,
    QCheckBox,
    QComboBox,
    QDoubleSpinBox,
    QFrame,
    QHBoxLayout,
    QLabel,
    QMainWindow,
    QMessageBox,
    QPushButton,
    QSizePolicy,
    QSpinBox,
    QTextEdit,
    QVBoxLayout,
    QWidget,
)

from harness.backends import GenerateConfig, create_backend
from harness.config import HarnessConfig, ModelConfig, SafetyConfig, load_config, save_config
from harness.config_commands import select_model, show_config
from harness.core.agent import Conversation
from harness.core.context import ContextManager
from harness.doctor import format_checks, run_checks
from harness.models import discover_gguf_models, display_model_path
from harness.paths import ensure_base_dirs, harness_root, plugins_dir
from harness.storage.sessions import ConversationStore, list_sessions, read_session
from harness.storage.tool_log import log_tool_event
from harness.tools import (
    ToolRegistry,
    register_filesystem_tools,
    register_packaging_tools,
    register_self_modify_tools,
)
from harness.tools.plugin_loader import load_generated_tools


APP_QSS = """
QMainWindow, QWidget {
    background: #101418;
    color: #e8edf2;
    font-family: "Segoe UI";
    font-size: 10pt;
}
QFrame#Sidebar {
    background: #171d23;
    border-right: 1px solid #2b3642;
}
QFrame#Card {
    background: #1f2730;
    border: 1px solid #2b3642;
    border-radius: 10px;
}
QLabel#Title {
    font-size: 24px;
    font-weight: 700;
}
QLabel#Subtitle, QLabel#Muted {
    color: #9aa8b5;
}
QLabel#SectionTitle {
    font-size: 13px;
    font-weight: 700;
}
QComboBox, QTextEdit {
    background: #0d1116;
    color: #e8edf2;
    border: 1px solid #2b3642;
    border-radius: 8px;
    padding: 8px;
    selection-background-color: #1677b9;
}
QTextEdit#Transcript {
    border-radius: 12px;
    padding: 14px;
}
QPushButton {
    background: #24313d;
    color: #e8edf2;
    border: 1px solid #344554;
    border-radius: 8px;
    padding: 9px 12px;
}
QPushButton:hover {
    background: #2d3c4a;
}
QPushButton#PrimaryButton {
    background: #1677b9;
    border-color: #55b6ff;
    font-weight: 700;
}
QPushButton#PrimaryButton:hover {
    background: #1c8ed8;
}
"""


class WorkerSignals(QObject):
    chunk = Signal(str)
    error = Signal(str)
    tool = Signal(str)
    finished = Signal()


class PromptWorker(QRunnable):
    def __init__(self, window: "HarnessWindow", prompt: str, config: HarnessConfig):
        super().__init__()
        self.window = window
        self.prompt = prompt
        self.config = config
        self.signals = WorkerSignals()

    @Slot()
    def run(self) -> None:
        try:
            convo = self.window.conversation(self.signals.tool, self.config)
            for chunk in convo.stream_ask(self.prompt):
                self.signals.chunk.emit(chunk)
        except Exception as exc:
            self.signals.error.emit(f"Cannot start model backend: {exc}")
        finally:
            self.signals.finished.emit()


class HarnessWindow(QMainWindow):
    def __init__(self):
        super().__init__()
        self.setWindowTitle("CrackStack Harness")
        self.resize(1180, 760)
        self.setMinimumSize(980, 660)
        self.thread_pool = QThreadPool.globalInstance()
        self._conversation: Conversation | None = None
        self._conversation_config: HarnessConfig | None = None
        self._cancel_event = Event()
        self._busy = False

        self._build()
        self.load_settings()
        self.refresh_models()
        self.refresh_sessions()
        self.run_doctor()

    def _build(self) -> None:
        shell = QWidget()
        layout = QHBoxLayout(shell)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        self.setCentralWidget(shell)

        sidebar = QFrame()
        sidebar.setObjectName("Sidebar")
        sidebar.setFixedWidth(330)
        side = QVBoxLayout(sidebar)
        side.setContentsMargins(22, 22, 22, 22)
        side.setSpacing(14)
        layout.addWidget(sidebar)

        title = QLabel("CrackStack")
        title.setObjectName("Title")
        side.addWidget(title)
        subtitle = QLabel("Local LLM harness")
        subtitle.setObjectName("Subtitle")
        side.addWidget(subtitle)

        model_card = self._card()
        model_layout = QVBoxLayout(model_card)
        model_layout.setContentsMargins(14, 14, 14, 14)
        model_layout.setSpacing(10)
        model_title = QLabel("Model")
        model_title.setObjectName("SectionTitle")
        model_layout.addWidget(model_title)
        self.model_combo = QComboBox()
        self.model_combo.setMinimumHeight(38)
        model_layout.addWidget(self.model_combo)
        refresh = QPushButton("Refresh Models")
        refresh.clicked.connect(self.refresh_models)
        model_layout.addWidget(refresh)
        select = QPushButton("Use Selected Model")
        select.setObjectName("PrimaryButton")
        select.clicked.connect(self.select_current_model)
        model_layout.addWidget(select)
        side.addWidget(model_card)

        settings_card = self._card()
        settings_layout = QVBoxLayout(settings_card)
        settings_layout.setContentsMargins(14, 14, 14, 14)
        settings_layout.setSpacing(10)
        settings_title = QLabel("Generation")
        settings_title.setObjectName("SectionTitle")
        settings_layout.addWidget(settings_title)
        self.context_spin = self._spin(512, 262144, 512)
        self.gpu_spin = self._spin(0, 999, 1)
        self.max_tokens_spin = self._spin(1, 32768, 32)
        self.temperature_spin = QDoubleSpinBox()
        self.temperature_spin.setRange(0.0, 2.0)
        self.temperature_spin.setSingleStep(0.05)
        self.temperature_spin.setDecimals(2)
        for label, widget in (
            ("Context", self.context_spin),
            ("GPU layers", self.gpu_spin),
            ("Max tokens", self.max_tokens_spin),
            ("Temperature", self.temperature_spin),
        ):
            settings_layout.addWidget(QLabel(label))
            settings_layout.addWidget(widget)
        self.dry_run_check = QCheckBox("Dry run")
        self.self_modify_check = QCheckBox("Self-modify tools")
        settings_layout.addWidget(self.dry_run_check)
        settings_layout.addWidget(self.self_modify_check)
        for widget in (
            self.context_spin,
            self.gpu_spin,
            self.max_tokens_spin,
            self.temperature_spin,
        ):
            widget.valueChanged.connect(self._settings_changed)
        self.dry_run_check.toggled.connect(self._settings_changed)
        self.self_modify_check.toggled.connect(self._settings_changed)
        save_settings = QPushButton("Save Settings")
        save_settings.clicked.connect(self.save_settings)
        settings_layout.addWidget(save_settings)
        side.addWidget(settings_card)

        sessions_card = self._card()
        sessions_layout = QVBoxLayout(sessions_card)
        sessions_layout.setContentsMargins(14, 14, 14, 14)
        sessions_layout.setSpacing(10)
        sessions_title = QLabel("Sessions")
        sessions_title.setObjectName("SectionTitle")
        sessions_layout.addWidget(sessions_title)
        self.session_combo = QComboBox()
        sessions_layout.addWidget(self.session_combo)
        load_session = QPushButton("Load Session")
        load_session.clicked.connect(self.load_selected_session)
        sessions_layout.addWidget(load_session)
        refresh_sessions = QPushButton("Refresh Sessions")
        refresh_sessions.clicked.connect(self.refresh_sessions)
        sessions_layout.addWidget(refresh_sessions)
        side.addWidget(sessions_card)

        for label, slot in (
            ("Run Doctor", self.run_doctor),
            ("Show Tools", self.show_tools),
            ("Show Config", self.show_config),
            ("Clear Transcript", self.clear_output),
        ):
            button = QPushButton(label)
            button.clicked.connect(slot)
            side.addWidget(button)

        status_card = self._card()
        status_layout = QVBoxLayout(status_card)
        status_layout.setContentsMargins(14, 14, 14, 14)
        status_layout.setSpacing(8)
        status_title = QLabel("Status")
        status_title.setObjectName("SectionTitle")
        self.status_label = QLabel()
        self.status_label.setObjectName("Muted")
        self.status_label.setWordWrap(True)
        status_layout.addWidget(status_title)
        status_layout.addWidget(self.status_label)
        side.addWidget(status_card)
        side.addStretch(1)

        main = QWidget()
        main_layout = QVBoxLayout(main)
        main_layout.setContentsMargins(24, 22, 24, 18)
        main_layout.setSpacing(14)
        layout.addWidget(main, 1)

        header = QLabel("Conversation")
        header.setObjectName("Title")
        main_layout.addWidget(header)
        hint = QLabel("Add a GGUF model, select it, then send prompts. Tool calls are logged on the drive.")
        hint.setObjectName("Subtitle")
        main_layout.addWidget(hint)

        self.transcript = QTextEdit()
        self.transcript.setObjectName("Transcript")
        self.transcript.setReadOnly(True)
        self.transcript.setSizePolicy(QSizePolicy.Policy.Expanding, QSizePolicy.Policy.Expanding)
        main_layout.addWidget(self.transcript, 1)

        composer = QHBoxLayout()
        composer.setSpacing(12)
        self.prompt = QTextEdit()
        self.prompt.setFixedHeight(108)
        self.prompt.setPlaceholderText("Ask the local model to inspect files, write code, create archives, or explain something...")
        composer.addWidget(self.prompt, 1)
        self.send_button = QPushButton("Send")
        self.send_button.setObjectName("PrimaryButton")
        self.send_button.setFixedWidth(120)
        self.send_button.setMinimumHeight(46)
        self.send_button.clicked.connect(self.send_prompt)
        composer.addWidget(self.send_button, alignment=Qt.AlignmentFlag.AlignBottom)
        self.stop_button = QPushButton("Stop")
        self.stop_button.setFixedWidth(92)
        self.stop_button.setMinimumHeight(46)
        self.stop_button.setEnabled(False)
        self.stop_button.clicked.connect(self.cancel_prompt)
        composer.addWidget(self.stop_button, alignment=Qt.AlignmentFlag.AlignBottom)
        main_layout.addLayout(composer)

    def _card(self) -> QFrame:
        card = QFrame()
        card.setObjectName("Card")
        return card

    def _spin(self, minimum: int, maximum: int, step: int) -> QSpinBox:
        spin = QSpinBox()
        spin.setRange(minimum, maximum)
        spin.setSingleStep(step)
        return spin

    def refresh_models(self) -> None:
        current = self.model_combo.currentText()
        self.model_combo.clear()
        models = [display_model_path(path) for path in discover_gguf_models()]
        self.model_combo.addItems(models)
        if current:
            index = self.model_combo.findText(current)
            if index >= 0:
                self.model_combo.setCurrentIndex(index)
        selected = self.model_combo.currentText() or "none"
        self.status_label.setText(f"Root: {harness_root()}\nModels found: {len(models)}\nSelected: {selected}")

    def refresh_sessions(self) -> None:
        current = self.session_combo.currentData()
        self.session_combo.clear()
        for session in list_sessions()[:50]:
            self.session_combo.addItem(f"{session.session_id} ({session.size} bytes)", session.session_id)
        if current:
            index = self.session_combo.findData(current)
            if index >= 0:
                self.session_combo.setCurrentIndex(index)

    def load_selected_session(self) -> None:
        session_id = self.session_combo.currentData()
        if not session_id:
            QMessageBox.information(self, "CrackStack", "No saved sessions found.")
            return
        try:
            records = read_session(session_id)
        except Exception as exc:
            QMessageBox.critical(self, "Sessions", str(exc))
            return
        self.clear_output()
        for record in records:
            payload = record.get("payload", {})
            if record.get("type") != "message":
                continue
            role = payload.get("role", "event")
            content = payload.get("content", "")
            if role == "user":
                self._append_user(content)
            elif role == "assistant":
                self._append_assistant_header()
                self._append_raw(content + "\n")
            elif role == "tool":
                self._append_tool(content)
            else:
                self._append_system(content)
        self._conversation = None
        self._conversation_config = None

    def load_settings(self) -> None:
        config = load_config()
        self.context_spin.setValue(config.model.context_size)
        self.gpu_spin.setValue(config.model.gpu_layers)
        self.max_tokens_spin.setValue(config.model.max_tokens)
        self.temperature_spin.setValue(config.model.temperature)
        self.dry_run_check.setChecked(config.safety.dry_run)
        self.self_modify_check.setChecked(config.safety.self_modify)

    def _settings_changed(self, *_args) -> None:
        self._conversation = None
        self._conversation_config = None

    def _live_config(self) -> HarnessConfig:
        config = load_config()
        return HarnessConfig(
            model=ModelConfig(
                backend=config.model.backend,
                path=config.model.path,
                context_size=self.context_spin.value(),
                gpu_layers=self.gpu_spin.value(),
                temperature=self.temperature_spin.value(),
                max_tokens=self.max_tokens_spin.value(),
            ),
            workspace=config.workspace,
            safety=SafetyConfig(
                self_modify=self.self_modify_check.isChecked(),
                sandbox=config.safety.sandbox,
                allow_outside_workspace=config.safety.allow_outside_workspace,
                dry_run=self.dry_run_check.isChecked(),
                max_file_bytes=config.safety.max_file_bytes,
                max_search_matches=config.safety.max_search_matches,
            ),
        )

    def save_settings(self) -> None:
        save_config(self._live_config())
        self._conversation = None
        self._conversation_config = None
        self._append_system("settings saved")

    def select_current_model(self) -> None:
        value = self.model_combo.currentText()
        if not value:
            QMessageBox.information(self, "CrackStack", "Put a .gguf file in models/ first.")
            return
        try:
            result = select_model(value)
        except Exception as exc:
            QMessageBox.critical(self, "Config", str(exc))
            return
        self._append_system(result)
        self._conversation = None
        self._conversation_config = None
        self.run_doctor()

    def run_doctor(self) -> None:
        try:
            text = format_checks(run_checks(load_config()))
        except Exception as exc:
            text = f"doctor failed: {exc}"
        self._append_system("[doctor]\n" + text)

    def show_tools(self) -> None:
        registry = self._registry(load_config())
        lines = [f"{spec['name']}: {spec['description']}" for spec in registry.specs()]
        self._append_tool("[tools]\n" + "\n".join(lines))

    def show_config(self) -> None:
        try:
            text = show_config()
        except Exception as exc:
            text = f"config failed: {exc}"
        self._append_system("[config]\n" + text)

    def send_prompt(self) -> None:
        text = self.prompt.toPlainText().strip()
        if not text:
            return
        self.prompt.clear()
        self._cancel_event.clear()
        self._busy = True
        self.send_button.setEnabled(False)
        self.stop_button.setEnabled(True)
        self._append_user(text)
        self._append_assistant_header()
        config = self._conversation_config or self._live_config()
        self._conversation_config = config
        worker = PromptWorker(self, text, config)
        worker.signals.chunk.connect(self._append_raw)
        worker.signals.error.connect(self._append_error)
        worker.signals.tool.connect(self._append_tool)
        worker.signals.finished.connect(self._prompt_finished)
        self.thread_pool.start(worker)

    def cancel_prompt(self) -> None:
        if self._busy:
            self._cancel_event.set()
            self.stop_button.setEnabled(False)
            self._append_system("cancel requested")

    def _prompt_finished(self) -> None:
        self._busy = False
        self.send_button.setEnabled(True)
        self.stop_button.setEnabled(False)
        self.refresh_sessions()

    def clear_output(self) -> None:
        self.transcript.clear()

    def conversation(
        self,
        tool_signal: Signal | None = None,
        config: HarnessConfig | None = None,
    ) -> Conversation:
        if self._conversation is not None:
            return self._conversation
        config = config or self._conversation_config or self._live_config()
        self._conversation_config = config
        backend = create_backend(config.model)
        registry = self._registry(config)
        store = ConversationStore()

        def tool_log(kind: str, message: str) -> None:
            log_tool_event(store.session_id, kind, message)
            text = f"[tool:{kind}] {message}"
            if tool_signal is not None:
                tool_signal.emit(text)
            else:
                self._append_tool(text)

        self._conversation = Conversation(
            backend=backend,
            generate_config=GenerateConfig(
                max_tokens=config.model.max_tokens,
                temperature=config.model.temperature,
            ),
            tools=registry,
            tool_observer=tool_log,
            cancel_checker=self._cancel_event.is_set,
            context_manager=ContextManager(context_window=config.model.context_size),
            store=store,
        )
        return self._conversation

    def _registry(self, config) -> ToolRegistry:
        registry = ToolRegistry()
        register_filesystem_tools(registry, config)
        register_packaging_tools(registry, config)
        load_generated_tools(plugins_dir() / "generated_tools", registry)
        register_self_modify_tools(registry, config)
        return registry

    def _append_html(self, html: str) -> None:
        self.transcript.moveCursor(self.transcript.textCursor().MoveOperation.End)
        self.transcript.insertHtml(html)
        self.transcript.moveCursor(self.transcript.textCursor().MoveOperation.End)

    def _append_user(self, text: str) -> None:
        self._append_html(f"<p style='color:#55b6ff;font-weight:700;'>user</p><p>{self._escape(text)}</p>")

    def _append_assistant_header(self) -> None:
        self._append_html("<p style='color:#7bd88f;font-weight:700;'>assistant</p>")

    def _append_system(self, text: str) -> None:
        self._append_html(f"<pre style='color:#9aa8b5;white-space:pre-wrap;'>{self._escape(text)}</pre>")

    def _append_tool(self, text: str) -> None:
        self._append_html(f"<pre style='color:#ffcf66;white-space:pre-wrap;'>{self._escape(text)}</pre>")

    def _append_error(self, text: str) -> None:
        self._append_html(f"<pre style='color:#ff7a7a;white-space:pre-wrap;'>{self._escape(text)}</pre>")

    def _append_raw(self, text: str) -> None:
        self._append_html(self._escape(text).replace("\n", "<br>"))

    def _escape(self, text: str) -> str:
        return (
            text.replace("&", "&amp;")
            .replace("<", "&lt;")
            .replace(">", "&gt;")
            .replace('"', "&quot;")
        )


def main() -> int:
    ensure_base_dirs()
    app = QApplication.instance() or QApplication(sys.argv)
    app.setStyleSheet(APP_QSS)
    app.setFont(QFont("Segoe UI", 10))
    window = HarnessWindow()
    window.show()
    return app.exec()
